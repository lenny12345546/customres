import sys
import win32api
from PyQt6.QtWidgets import (QApplication, QMainWindow, QWidget, QVBoxLayout,
                            QComboBox, QPushButton, QLabel, QMessageBox,
                            QHBoxLayout, QLineEdit, QGroupBox)
from PyQt6.QtCore import Qt
from PyQt6.QtGui import QIntValidator
from screeninfo import get_monitors

class DisplaySettingsApp(QMainWindow):
    def __init__(self):
        super().__init__()
        self.setWindowTitle("Display Settings Manager")
        self.setFixedSize(500, 400)

        # Create central widget and layout
        central_widget = QWidget()
        self.setCentralWidget(central_widget)
        layout = QVBoxLayout(central_widget)
        layout.setAlignment(Qt.AlignmentFlag.AlignTop)
        layout.setSpacing(20)

        # Get available display modes
        self.device = win32api.EnumDisplayDevices(None, 0)
        self.settings = win32api.EnumDisplaySettings(self.device.DeviceName, -1)
        self.available_modes = self.get_display_modes()

        # Create preset settings group
        preset_group = QGroupBox("Preset Settings")
        preset_layout = QVBoxLayout()
        
        # Create resolution dropdown
        resolution_label = QLabel("Select Resolution:")
        self.resolution_combo = QComboBox()
        self.resolution_combo.addItems(self.available_modes.keys())

        # Create refresh rate dropdown
        refresh_label = QLabel("Select Refresh Rate:")
        self.refresh_combo = QComboBox()
        self.resolution_combo.currentTextChanged.connect(self.update_refresh_rates)
        
        # Add preset widgets to layout
        preset_layout.addWidget(resolution_label)
        preset_layout.addWidget(self.resolution_combo)
        preset_layout.addWidget(refresh_label)
        preset_layout.addWidget(self.refresh_combo)
        preset_group.setLayout(preset_layout)
        
        # Create custom settings group
        custom_group = QGroupBox("Custom Settings")
        custom_layout = QVBoxLayout()
        
        # Create custom resolution inputs
        res_layout = QHBoxLayout()
        width_label = QLabel("Width:")
        self.width_input = QLineEdit()
        self.width_input.setValidator(QIntValidator(1, 9999))
        height_label = QLabel("Height:")
        self.height_input = QLineEdit()
        self.height_input.setValidator(QIntValidator(1, 9999))
        res_layout.addWidget(width_label)
        res_layout.addWidget(self.width_input)
        res_layout.addWidget(height_label)
        res_layout.addWidget(self.height_input)
        
        # Create custom refresh rate input
        refresh_layout = QHBoxLayout()
        custom_refresh_label = QLabel("Refresh Rate (Hz):")
        self.refresh_input = QLineEdit()
        self.refresh_input.setValidator(QIntValidator(1, 360))
        refresh_layout.addWidget(custom_refresh_label)
        refresh_layout.addWidget(self.refresh_input)
        
        # Add custom widgets to layout
        custom_layout.addLayout(res_layout)
        custom_layout.addLayout(refresh_layout)
        custom_group.setLayout(custom_layout)
        
        # Create apply buttons
        preset_button = QPushButton("Apply Preset Settings")
        preset_button.clicked.connect(self.apply_preset_settings)
        custom_button = QPushButton("Apply Custom Settings")
        custom_button.clicked.connect(self.apply_custom_settings)
        
        # Add all widgets to main layout
        layout.addWidget(preset_group)
        layout.addWidget(custom_group)
        layout.addWidget(preset_button)
        layout.addWidget(custom_button)

        # Initialize refresh rates for first resolution
        self.update_refresh_rates()

    def get_display_modes(self):
        modes = {}
        mode_num = 0
        try:
            while True:
                mode = win32api.EnumDisplaySettings(self.device.DeviceName, mode_num)
                resolution = f"{mode.PelsWidth}x{mode.PelsHeight}"
                if resolution not in modes:
                    modes[resolution] = set()
                modes[resolution].add(mode.DisplayFrequency)
                mode_num += 1
        except:
            pass
        return modes

    def update_refresh_rates(self):
        current_resolution = self.resolution_combo.currentText()
        self.refresh_combo.clear()
        if current_resolution in self.available_modes:
            refresh_rates = sorted(list(self.available_modes[current_resolution]))
            self.refresh_combo.addItems([str(rate) for rate in refresh_rates])

    def apply_preset_settings(self):
        try:
            resolution = self.resolution_combo.currentText()
            refresh_rate = int(self.refresh_combo.currentText())
            width, height = map(int, resolution.split('x'))
            self.change_display_settings(width, height, refresh_rate)
        except Exception as e:
            QMessageBox.critical(self, "Error", f"An error occurred: {str(e)}")
            
    def apply_custom_settings(self):
        try:
            width = self.width_input.text().strip()
            height = self.height_input.text().strip()
            refresh_rate = self.refresh_input.text().strip()
            
            if not width or not height or not refresh_rate:
                QMessageBox.warning(self, "Error", "Please fill in all custom settings fields!")
                return
                
            width = int(width)
            height = int(height)
            refresh_rate = int(refresh_rate)
            
            if width < 640 or height < 480:
                if QMessageBox.question(self, "Warning", 
                    "Very low resolution might make your display unusable.\nDo you want to continue?", 
                    QMessageBox.StandardButton.Yes | QMessageBox.StandardButton.No) == QMessageBox.StandardButton.No:
                    return
                    
            if refresh_rate > 360:
                if QMessageBox.question(self, "Warning", 
                    "Very high refresh rate might not be supported.\nDo you want to continue?", 
                    QMessageBox.StandardButton.Yes | QMessageBox.StandardButton.No) == QMessageBox.StandardButton.No:
                    return
                    
            self.change_display_settings(width, height, refresh_rate)
        except Exception as e:
            QMessageBox.critical(self, "Error", f"An error occurred: {str(e)}")
            
    def change_display_settings(self, width, height, refresh_rate):
        try:
            # Prepare display settings
            mode = win32api.EnumDisplaySettings(self.device.DeviceName, -1)
            mode.PelsWidth = width
            mode.PelsHeight = height
            mode.DisplayFrequency = refresh_rate

            # Change display settings
            result = win32api.ChangeDisplaySettings(mode, 0)
            
            if result == win32api.DISP_CHANGE_SUCCESSFUL:
                QMessageBox.information(self, "Success", "Display settings changed successfully!")
            else:
                QMessageBox.warning(self, "Error", "Failed to change display settings!")
                
        except Exception as e:
            QMessageBox.critical(self, "Error", f"An error occurred: {str(e)}")

def main():
    app = QApplication(sys.argv)
    window = DisplaySettingsApp()
    window.show()
    sys.exit(app.exec())

if __name__ == '__main__':
    main()
